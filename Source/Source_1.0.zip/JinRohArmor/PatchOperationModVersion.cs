﻿using System.Collections.Generic;
using System.Xml;
using Verse;

namespace JinRohArmor
{
    // Token: 0x02000002 RID: 2
    public class PatchOperationModVersion : PatchOperation
    {
        // Token: 0x04000003 RID: 3
        private PatchOperation match;

        // Token: 0x04000002 RID: 2
        private List<string> mods;

        // Token: 0x04000001 RID: 1
        private List<int> modSettingverNum;

        // Token: 0x04000004 RID: 4
        private PatchOperation nomatch;

        // Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
        protected override bool ApplyWorker(XmlDocument xml)
        {
            var b = false;
            var b1 = false;
            foreach (var name in mods)
            {
                if (!ModLister.HasActiveModWithName(name))
                {
                    continue;
                }

                b = true;
                break;
            }

            foreach (var checkedout in modSettingverNum)
            {
                if (!CheckSettingsVersionNumber(checkedout))
                {
                    continue;
                }

                b1 = true;
                break;
            }

            if (!b || !b1)
            {
                return true;
            }

            Log.Message("[JinRoh Armor] PatchOperationModVersion passed: Loading selected patch");
            if (match != null)
            {
                return match.Apply(xml);
            }

            if (nomatch != null)
            {
                return nomatch.Apply(xml);
            }

            return true;
        }

        // Token: 0x06000002 RID: 2 RVA: 0x00002138 File Offset: 0x00000338
        public override string ToString()
        {
            return $"{base.ToString()}({mods.ToCommaList()})";
        }

        // Token: 0x06000003 RID: 3 RVA: 0x00002168 File Offset: 0x00000368
        public static bool CheckSettingsVersionNumber(int checkedout)
        {
            var versionNumber = LoadedModManager.GetMod<JinRohSettings.JinRohMod>().GetSettings<JinRohSettings>()
                .versionNumber;
            return versionNumber == checkedout;
        }
    }
}