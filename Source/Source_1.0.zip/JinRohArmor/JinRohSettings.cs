﻿using UnityEngine;
using Verse;

namespace JinRohArmor
{
    // Token: 0x02000003 RID: 3
    public class JinRohSettings : ModSettings
    {
        // Token: 0x04000005 RID: 5
        public int versionNumber;

        // Token: 0x06000005 RID: 5 RVA: 0x000021A1 File Offset: 0x000003A1
        public override void ExposeData()
        {
            Scribe_Values.Look(ref versionNumber, "versionNumber");
            base.ExposeData();
        }

        // Token: 0x02000004 RID: 4
        public class JinRohMod : Mod
        {
            // Token: 0x04000006 RID: 6
            private readonly JinRohSettings settings1;

            // Token: 0x06000007 RID: 7 RVA: 0x000021CE File Offset: 0x000003CE
            public JinRohMod(ModContentPack content) : base(content)
            {
                settings1 = GetSettings<JinRohSettings>();
            }

            // Token: 0x06000008 RID: 8 RVA: 0x000021E8 File Offset: 0x000003E8
            public override void DoSettingsWindowContents(Rect inRect)
            {
                var listing_Standard = new Listing_Standard();
                listing_Standard.Begin(inRect);
                listing_Standard.Label("JRAUsePatchCEDesc".Translate());
                if (listing_Standard.RadioButton("JRAUsePatchVanilla".Translate(), settings1.versionNumber == 0,
                    8f))
                {
                    settings1.versionNumber = 0;
                }

                if (listing_Standard.RadioButton("JRAUsePatchCE15".Translate(), settings1.versionNumber == 1,
                    8f))
                {
                    settings1.versionNumber = 1;
                    Log.Message("[JinRoh Armor] Settings: Patch 1.5 Selected");
                }

                if (listing_Standard.RadioButton("JRAUsePatchCE16".Translate(), settings1.versionNumber == 2,
                    8f))
                {
                    settings1.versionNumber = 2;
                    Log.Message("[JinRoh Armor] Settings: Patch 1.6 Selected");
                }

                listing_Standard.End();
            }

            // Token: 0x06000009 RID: 9 RVA: 0x000022DC File Offset: 0x000004DC
            public override string SettingsCategory()
            {
                return "JRASettingsModName".Translate();
            }
        }
    }
}